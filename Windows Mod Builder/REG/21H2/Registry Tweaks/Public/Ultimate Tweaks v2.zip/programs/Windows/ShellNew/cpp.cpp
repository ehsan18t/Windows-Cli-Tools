#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
	/* YOUR CODE START FROM HERE */
	return 0;
}